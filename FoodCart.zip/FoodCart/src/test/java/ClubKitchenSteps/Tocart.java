package ClubKitchenSteps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Tocart {

	RemoteWebDriver driver;
	JavascriptExecutor js = (JavascriptExecutor) driver;
	

	@Given("^the User is on ClubKitchen then to mamacita$")
	public void the_User_is_on_ClubKitchen() {

		System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
		driver = new ChromeDriver();

		driver.navigate().to("https://clubkitchen.at");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		WebElement verifyLogo = driver.findElement(By.xpath("//a[@class='logo--link']//picture//img"));
		System.out.println(verifyLogo.isDisplayed());
		
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Actions act = new Actions(driver);
		WebElement mamacita =driver.findElement(By.xpath("(//a[contains(text(),'JETZT BESTELLEN')])[3]"));
			 
			    act.sendKeys(mamacita,Keys.PAGE_DOWN).perform();
		
		//js.executeScript("arguments[0].scrollIntoView();", mamacita);
		//mamacita.sendKeys(Keys.PAGE_DOWN);
		//mamacita.click();
		
		

	}

	@When("^he clcik on the To the menu and address$")
	public void he_clcik_on_the_To_the_menu() {
		WebElement menu = driver.findElement(By.xpath("//a[@class='btn club-home-button shop-menu-btn']"));
		menu.click();
		WebElement enterAddress = driver.findElement(By.xpath("//input[@id='address-input']"));
		enterAddress.clear();
		enterAddress.click();
		enterAddress.sendKeys("Semperstraße 44, 1180 Wien, Austria");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		WebElement clickContinue = driver.findElement(By.xpath("//a[@class='popup-no-address-link']"));
		clickContinue.click();
		

		// Write code here that turns the phrase above into concrete actions

	}

	@When("^he added a food to the cart$")
	public void he_added_a_food_to_the_cart() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement addCart = driver.findElement(By.xpath("(//*[@class='buybox--button--image-overlay'])[3]"));
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOf(addCart));
		
		addCart.sendKeys(Keys.PAGE_DOWN);
		addCart.click();
		WebElement addCartFood = driver.findElement(By.xpath("(//*[@class='buybox--button--image-overlay'])[9]"));
		addCartFood.click();
		

	}

	@When("^now food is ready to order$")
	public void now_food_is_ready_to_order() {

	}

}
