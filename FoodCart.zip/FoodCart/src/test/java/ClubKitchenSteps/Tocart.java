package ClubKitchenSteps;

import java.awt.Robot;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class Tocart {
	
	RemoteWebDriver driver;
	JavascriptExecutor js = (JavascriptExecutor)driver;

	@Given("^the User is on ClubKitchen$")
	public void the_User_is_on_ClubKitchen() {
		
		System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
		driver = new ChromeDriver();

		driver.navigate().to("https://clubkitchen.at");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		WebElement verifyLogo = driver.findElement(By.xpath("//a[@class='logo--link']//picture//img"));
		System.out.println(verifyLogo.isDisplayed());
		//WebElement mamacita = driver.findElement(By.xpath("(//a[contains(text(),'JETZT BESTELLEN')])[3]"));
		//js.executeScript("arguments[0].scrollIntoView();", mamacita);
		//mamacita.click();
		
		

	}

	@When("^he clcik on the To the menu$")
	public void he_clcik_on_the_To_the_menu() {

		WebElement menu = driver.findElement(By.xpath("//a[@class='btn club-home-button shop-menu-btn']"));
		menu.click();

		// Write code here that turns the phrase above into concrete actions

	}

	@When("^he entered the address and click on continue$")
	public void he_entered_the_address_and_click_on_continue() {
		WebElement enterAddress = driver.findElement(By.xpath("//input[@id='address-input']"));
		enterAddress.clear();
		enterAddress.click();
		enterAddress.sendKeys("Semperstraße 44, 1180 Wien, Austria");
		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS) ;


		//WebElement removeAd = driver.findElement(By.xpath("//*[@class='honest-mt-10 no-address-container']"));
		//removeAd.click();

		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS) ;
		WebElement clickContinue = driver.findElement(By.xpath("//a[@class='popup-no-address-link']"));
		clickContinue.click();

		

	}

	@When("^he added a food to the cart$")
	public void he_added_a_food_to_the_cart() {
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		WebElement addCart = driver.findElement(By.xpath("(//button[contains(text(), ' + In den Einkaufswagen ')])[1]"));
		js.executeScript("window.scrollBy(0,1000)");
		//js.executeScript("arguments[0].scrollIntoView();", addCart);
		addCart.click();
		/*
		 * WebElement addCart = driver.findElement(By.
		 * xpath("(//button[contains(text(), ' + In den Einkaufswagen ')])[1]"));
		 * addCart.isDisplayed(); WebDriverWait wait = new WebDriverWait(driver,1000);
		 * wait.until(isTrue);
		 * 
		 * 
		 * 
		 * //DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		 * //capabilities.chrome().setJavascriptEnabled(true); WebElement mamacitaLogo =
		 * driver.findElement(By.
		 * xpath("//a[@class='navigation--link logo--link mamacita']"));
		 * mamacitaLogo.isDisplayed();
		 */
		
		
		
		
		
		
		//js.executeScript("window.scrollBy(0,1000)");

	}

	@When("^now food is ready to order$")
	public void now_food_is_ready_to_order() {

	}

}
